<?php

$db=mysqli_connect("localhost","root","","angularjsproject");
if(!$db)
die("NOT CON");

$data = json_decode(file_get_contents("php://input"));


$username = mysqli_real_escape_string($db,$data->username);
$password = mysqli_real_escape_string($db,$data->password);

$query=mysqli_query($db, "INSERT INTO employee VALUES('".$username."','".$password."')");
if($query){
	echo 'success';
}
else{
	echo 'insertion unsuccessfull';
}
?>






