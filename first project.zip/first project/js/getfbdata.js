   
  $( document ).ready(function() {

    var myFacebookToken = 'EAACEdEose0cBAFWwfWZBGwaeANFrisD7q5pDKcpwGh0X9XthXOXvKTI6JBtdSoVQ3ZBcISqoRexIAKT7NDcZCtDxtYvwYEJZCvgZBjHzzx6gdViYuBnGTOMwUQ3zEcPiuT5l8TaxgRlHCkZCixeZCcBAUIq0GZA4gNJHdL1pZA9zr0wZDZD';

    function getFacebookInfo(){

        $.ajax('https://graph.facebook.com/me?access_token='+myFacebookToken,{

                success : function(response){
                    console.log(response);
                    console.log(typeof(response));
                    $("#myEmail").text(response.email);
                    $("#myProfileId").html('<a target="blank" href="https://facebook.com/'+response.id+'">https://facebook.com/'+response.id+'</a>');
                    $("#myHomeTown").text(response.hometown.name);
                    $("#Location").text(response.location.name);
                    $("#Birthday").text(response.birthday);
                    $("#Gender").text(response.gender);

                }
            }//end argument list 



        );// end ajax call 


      
    }// end get facebook info

    $("#facebookBtn").on('click',getFacebookInfo)
});