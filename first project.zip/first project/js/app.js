var routerApp = angular.module('routerApp', ['ui.router']);

routerApp.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
        
        // HOME STATES AND NESTED VIEWS ========================================
        .state('home', {
            url: '/home',
            templateUrl: 'home.html'
        })

         .state('knowme', {
            url: '/knowme',
            templateUrl: 'knowme.html'
        })

          .state('login', {
            url: '/login',
            templateUrl: 'login.html',
            controller: 'loginController'
        })
        
        // nested list with custom controller
        .state('home.list', {
            url: '/list',
            templateUrl: 'home-list.html',
            controller: function($scope) {
                $scope.dogs = ['Bernese', 'Husky', 'Goldendoodle'];
            }
        })
        
        // nested list with just some random string data
        .state('home.paragraph', {
            url: '/paragraph',
            template: 'I could sure use a drink right now.'
        })
        
        // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
        .state('about', {
            url: '/about',
            views: {
                '': { templateUrl: 'about.html' },
                'columnOne@about': { template: 'Look I am a column!' },
                'columnTwo@about': { 
                    templateUrl: 'table-data.html',
                    controller: 'scotchController'
                }
            }
            
        });
        
});

routerApp.controller('scotchController', function($scope) {
    
    $scope.message = 'test';
   
    $scope.scotches = [
        {
            name: 'Besan',
            price: 50
        },
        {
            name: 'papad',
            price: 10000
        },
        {
            name: 'Laddu',
            price: 20000
        }
    ];
    
});

routerApp.controller('loginController',function($scope,$http){
    $scope.insertdata = function(){
        $http.post("insert.php",{'username':$scope.username,'password':$scope.password})
        .success(function(data,status){
            console.log(data);
        });
    } 
});


